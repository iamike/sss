<template>
  <img class="VuetifyLogo" alt="Vuetify Logo" src="../assets/images/logo.svg">
</template>

<style>

</style>
